//Written by Elum Nyabando x500: nyaba009
import java.util.Arrays;

public class ArrayList<T extends Comparable<T>> implements List<T> {
    private T[] array;
    private int size;
    private boolean isSorted;

    public ArrayList() {
        array = (T[]) new Comparable[2]; // Initialize the array with a default size of 2
        size = 0; // Initialize the size to 0
        isSorted = true; // Initialize the isSorted to true
    }

    // Add an element to the end of the array
    public boolean add(T element) {
        if (element == null) {
            return false; // Return false if the element is null
        }
        if (size == array.length) {
            // If the array is full, create a new array with double the size
            T[] newArray = (T[]) new Comparable[array.length * 2];
            System.arraycopy(array, 0, newArray, 0, size);
            array = newArray; // Update the reference to the new array
        }
        array[size] = element; // Add the element to the end of the array
        size++; // Increment the size
        isSorted = false; // Set the isSorted to false
        return true; // Return true for successful addition
    }

    // Add an element at a specific index in the array
    public boolean add(int index, T element) {
        if (element == null || index < 0 || index > size) {
            return false; // Return false if the element is null or the index is out of bounds
        }
        if (size == array.length) {
            // If the array is full, create a new array with double the size
            T[] newArray = (T[]) new Comparable[array.length * 2];
            // Copy the elements before the index from the old array to the new array
            System.arraycopy(array, 0, newArray, 0, index);
            // Copy the elements after the index from the old array to the new array
            System.arraycopy(array, index, newArray, index + 1, size - index);
            array = newArray; // Update the reference to the new array
        } else {
            // Shift the elements after the index to the right to make space for the new element
            for (int i = size - 1; i >= index; i--) {
                array[i + 1] = array[i];
            }
        }
        array[index] = element; // Add the element at the specified index
        size++; // Increase the size
        isSorted = false; // Set the isSorted to false
        return true; // Return true to indicate successful addition
    }

    // Clear the array by setting the size to 0 and the isSorted to true
    public void clear() {
        size = 0;
        isSorted = true;
    }

    // Get the element at a specific index in the array
    public T get(int index) {
        if (index < 0 || index >= size) {
            return null; // Return null if the index is out of bounds
        }
        return array[index]; // Return the element at the specified index
    }

    // Get the index of the first occurrence of an element in the array
    public int indexOf(T element) {
        if (element == null) {
            return -1; // Return -1 if the element is null
        }
        for (int i = 0; i < size; i++) {
            if (array[i].equals(element)) {
                return i; // Return the index if the element is found
            }
        }
        return -1; // Return -1 if the element is not found
    }

    // Check if the array is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Get the size of the array
    public int size() {
        return size;
    }

    // Sort the array
    public void sort() {
        if (!isSorted) {
            Arrays.sort(array, 0, size);
            isSorted = true; // Set the isSorted to true
        }
    }

    // Remove the element at a specific index in the array
    public T remove(int index) {
        if (index < 0 || index >= size) {
            return null; // Return null if the index is out of bounds
        }
        T removedElement = array[index]; // Store the element to be removed
        // Shift the elements after the index to the left to fill the gap
        for (int i = index; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        size--; // Decrement the size
        isSorted = isSorted(); // Update the isSorted
        return removedElement; // Return the removed element
    }

    // Remove all elements that are not equal to the specific element
    public void equalTo(T element) {
        if (element != null) {
            for (int i = 0; i < size; i++) {
                if (!array[i].equals(element)) {
                    remove(i); // Remove the element if it is not equal to the specific element
                    i--; // Decrease the index to mark the removed element
                }
            }
        }
    }

    // Reverse the order of the elements in the array
    public void reverse() {
        for (int i = 0; i < size / 2; i++) {
            T temp = array[i];
            array[i] = array[size - i - 1];
            array[size - i - 1] = temp;
        }
    }

    // Remove elements from the array that are not present in another list
    public void intersect(List<T> otherList) {
        if (otherList != null) {
            ArrayList<T> other = (ArrayList<T>) otherList;
            sort();
            other.sort();
            int i = 0;
            int j = 0;
            while (i < size && j < other.size()) {
                int comparison = array[i].compareTo(other.get(j));
                if (comparison == 0) {
                    i++;
                    j++;
                } else if (comparison < 0) {
                    remove(i);
                } else {
                    j++;
                }
            }
            while (i < size) {
                remove(i);
            }
            isSorted = true;
        }
    }

    // Get the minimum element in the array
    public T getMin() {
        if (isSorted) {
            return array[0]; // Return the first element if the array is sorted
        } else {
            T min = array[0];
            for (int i = 1; i < size; i++) {
                if (array[i].compareTo(min) < 0) {
                    min = array[i];
                }
            }
            return min;
        }
    }

    // Get the maximum element in the array
    public T getMax() {
        if (isSorted) {
            return array[size]; // Return the last element if the array is sorted
        } else {
            T max = array[0];
            for (int i = 1; i < size; i++) {
                if (array[i].compareTo(max) > 0) {
                    max = array[i];
                }
            }
            return max;
        }
    }

    // Convert the array to a string
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < size; i++) {
            sb.append(array[i]);
            if (i < size - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    // Check if the array is sorted
    public boolean isSorted() {
        for (int i = 0; i < size - 1; i++) {
            if (((Comparable<T>) array[i]).compareTo(array[i + 1]) > 0) {
                return false; // Return false if the elements are not in order
            }
        }
        return true; // Return true if the elements are in order
    }
}
