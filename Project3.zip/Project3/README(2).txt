Elum Nyabando
x500: nyaba009
Chris Dovolis
CSCI 1933
15 November 2023

Project 3: List Implementation: ArrayLists vs. LinkedList

To run the file just make sure to unzip it and navigate to the correct folder when trying to run the code. I did not run into many issues while working on the project but I do feel as though I might have missed something along the way since there were a lot of times I had to go back and debug some certain methods like the sort method and the intersect method for both the Array and Linked List. I didn’t use any outside sources and the resources I did use mostly consisted of  TA’s and other course resources like the textbook.


“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
* Elum Nyabando