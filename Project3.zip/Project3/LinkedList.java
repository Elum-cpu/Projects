//Written by Elum Nyabando x500: nyaba009
public class LinkedList<T extends Comparable<T>> implements List<T> {
    private Node<T> head;
    private boolean isSorted;

    public LinkedList() {
        head = null; // Initialize the list with an empty head
        isSorted = true; // Initialize the isSorted to be true
    }

    @Override
    public boolean add(T element) {
        if (element == null) {
            return false;
        }
        if (head == null) {
            head = new Node<>(element);
        } else {
            Node<T> current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(new Node<>(element));
        }
        isSorted = false;
        return true;
    }

    @Override
    public boolean add(int index, T element) {
        if (element == null || index < 0 || index > size()) {
            return false;
        }
        if (index == 0) {
            head = new Node<>(element, head);
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.getNext();
            }
            current.setNext(new Node<>(element, current.getNext()));
        }
        isSorted = false;
        return true;
    }

    @Override
    public void clear() {
        head = null;
        isSorted = true;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= size()) {
            return null;
        }
        Node<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current.getData();
    }

    @Override
    public int indexOf(T element) {
        Node<T> current = head;
        int index = 0;
        while (current != null) {
            if (current.getData().equals(element)) {
                return index;
            }
            current = current.getNext();
            index++;
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public int size() {
        int count = 0;
        Node<T> current = head;
        while (current != null) {
            count++;
            current = current.getNext();
        }
        return count;
    }

    @Override
    public void sort() {
        if (isSorted) {
            return;
        }
        Node<T> current = head;
        Node<T> sorted = null;
        while (current != null) {
            Node<T> next = current.getNext();
            if (sorted == null || current.getData() == null || current.getData().compareTo(sorted.getData()) < 0) {
                current.setNext(sorted);
                sorted = current;
            } else {
                Node<T> temp = sorted;
                while (temp.getNext() != null && (current.getData() == null || current.getData().compareTo(temp.getNext().getData()) > 0)) {
                    temp = temp.getNext();
                }
                current.setNext(temp.getNext());
                temp.setNext(current);
            }
            current = next;
        }
        isSorted = true;
    }

    @Override
    public T remove(int index) {
        if (index < 0 || index >= size()) {
            return null;
        }
        if (index == 0) {
            T removedData = head.getData();
            head = head.getNext();
            return removedData;
        } else {
            Node<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.getNext();
            }
            T removedData = current.getNext().getData();
            current.setNext(current.getNext().getNext());
            return removedData;
        }
    }

    @Override
    public void equalTo(T element) {
        Node<T> current = head;
        Node<T> previous = null;
        boolean isSorted = true;
        while (current != null) {
            if (element == null) {
                return;
            }
            if (!current.getData().equals(element)) {
                if (previous == null) {
                    head = current.getNext();
                } else {
                    previous.setNext(current.getNext());
                }
            } else {
                if (previous != null && previous.getData().compareTo(current.getData()) > 0) {
                    isSorted = false;
                }
                previous = current;
            }
            current = current.getNext();
        }
        this.isSorted = isSorted;
    }

    @Override
    public void reverse() {
        Node<T> previous = null;
        Node<T> current = head;
        Node<T> next = null;
        while (current != null) {
            next = current.getNext();
            current.setNext(previous);
            previous = current;
            current = next;
        }
        head = previous;
    }

    // Remove elements from the list that are not present in another list
    @Override
    public void intersect(List<T> otherList) {
        if (otherList == null) {
            return;
        }
        List<T> other;
        if (otherList instanceof ArrayList) {
            other = (ArrayList<T>) otherList;
        } else if (otherList instanceof LinkedList) {
            other = (LinkedList<T>) otherList;
        } else {
            throw new IllegalArgumentException("Not a valid list type");
        }
        sort();
        Node<T> current = head;
        while (current != null) {
            if (other.indexOf(current.getData()) != -1) {
                System.out.println("Intersection found: " + current.getData());
            }
            current = current.getNext();
        }
        isSorted = true;
    }

    // Get the minimum element in the list
    @Override
    public T getMin() {
        if (isEmpty()) {
            return null;
        }
        Node<T> current = head;
        T min = current.getData();
        while (current != null) {
            if (current.getData().compareTo(min) < 0) {
                min = current.getData();
            }
            current = current.getNext();
        }
        return min;
    }

    // Get the maximum element in the list
    @Override
    public T getMax() {
        if (isEmpty()) {
            return null;
        }
        Node<T> current = head;
        T max = current.getData();
        while (current != null) {
            if (current.getData().compareTo(max) > 0) {
                max = current.getData();
            }
            current = current.getNext();
        }
        return max;
    }

    // Convert the LinkedList to a string
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node<T> current = head;
        while (current != null) {
            sb.append(current.getData()).append(" -> ");
            current = current.getNext();
        }
        sb.append("null");
        return sb.toString();
    }

    // Check if the list is sorted
    @Override
    public boolean isSorted() {
        return isSorted;
    }
}

