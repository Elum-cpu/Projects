﻿Elum Nyabando
x500: nyaba009
Project 3: Minefield
To run the file just make sure to unzip it and navigate to the correct folder when trying to run the code.
When entering the difficulty level make sure to type the numbers of the level rather than the string of the word.
I did run into a few issues trying to figure how to correctly mark the mines ands flags on the board.
I also had some trouble with evaluating and revealing the starting area on the project, but I do feel as though it came out pretty well
even if it isn’t perfect it still plays like the minesweeper game.
The only sources and resources that were used were from T.A. help and readings from the textbook and lecture.


“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the
‘Academic Integrity - Course Policy’ section of the course syllabus.”
* Elum Nyabando