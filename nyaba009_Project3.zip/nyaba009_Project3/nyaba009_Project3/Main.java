//Written by: Elum Nyabando x500: nyaba009

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to choose a difficulty level
        System.out.println("Choose a difficulty level: ");
        System.out.println("1. Easy");
        System.out.println("2. Medium");
        System.out.println("3. Hard");
        int difficultyLevel = scanner.nextInt();

        int rows, columns, mines, flags;

        // Set the dimensions and number of mines based on the chosen difficulty level
        if (difficultyLevel == 1) {
            rows = 5;
            columns = 5;
            mines = 5;
            flags = 5;
        } else if (difficultyLevel == 2) {
            rows = 9;
            columns = 9;
            mines = 12;
            flags = 12;
        } else if (difficultyLevel == 3) {
            rows = 20;
            columns = 20;
            mines = 40;
            flags = 40;
        } else {
            System.out.println("Invalid difficulty level. Exiting the game.");
            return;
        }

        // Create a new instance of the Minefield class
        Minefield minefield = new Minefield(rows, columns, mines);

        // Create mines in the minefield
        minefield.createMines(0, 0, mines);

        // Get the user input to enter the x coordinate
        System.out.print("Enter the x coordinate: ");
        int x = scanner.nextInt();

        // Get the user input to enter the y coordinate
        System.out.print("Enter the y coordinate: ");
        int y = scanner.nextInt();

        // Evaluate the field to determine the number of adjacent mines
        minefield.evaluateField();

        // Reveal the starting area based on the user's coordinates
        minefield.revealStartingArea(x, y);

        // Continue the game until it is over
        while (!minefield.gameOver()) {
            // Print the current state of the minefield
            System.out.println(minefield.toString());

            // Prompt the user to enter the x coordinate
            System.out.print("Enter the x coordinate: ");
            int xcor = scanner.nextInt();

            // Prompt the user to enter the y coordinate
            System.out.print("Enter the y coordinate: ");
            int ycor = scanner.nextInt();

            // Prompt the user to choose whether to place a flag or reveal the cell
            System.out.print("Enter 'true' to place a flag or 'false' to reveal the cell: ");
            boolean flag = scanner.nextBoolean();

            // Make a guess based on the user's input
            boolean hitMine = minefield.guess(xcor, ycor, flag);

            // Check if the guess hit a mine
            if (hitMine) {
                System.out.println("Game over! You hit a mine.");
                break;
            }
        }

        // Print the final state of the minefield
        System.out.println(minefield.toString());

        // Check if all non-mine cells have been revealed
        if (minefield.allNonMineRevealed()) {
            System.out.println("Congratulations! You won the game.");
        }
    }
}
