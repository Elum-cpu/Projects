//Written by: Elum Nyabando x500: nyaba009
import java.util.Queue;
import java.util.Random;

public class Minefield {
    // Define ANSI color codes
    public static final String ANSI_YELLOW_BRIGHT = "\u001B[33;1m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE_BRIGHT = "\u001b[34;1m";
    public static final String ANSI_BLUE = "\u001b[34m";
    public static final String ANSI_RED_BRIGHT = "\u001b[31;1m";
    public static final String ANSI_RED = "\u001b[31m";
    public static final String ANSI_GREEN = "\u001b[32m";
    public static final String ANSI_PURPLE = "\u001b[35m";
    public static final String ANSI_CYAN = "\u001b[36m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001b[47m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001b[45m";
    public static final String ANSI_GREY_BACKGROUND = "\u001b[0m";
    public static final String ANSI_RESTART = "\u001B[0m";

    // Define instance variables
    public final Cell[][] minefield;
    public final int rows;
    public final int columns;

    // Constructor
    public Minefield(int rows, int columns, int flags) { 
        this.rows = rows;
        this.columns = columns;
        minefield = new Cell[rows][columns];

        // Initialize the minefield with empty cells
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                minefield[i][j] = new Cell(false, "0");
            }
        }

        // Create mines in the minefield
        createMines(0, 0, flags);

        // Evaluate the minefield to determine the number of adjacent mines for each cell
        evaluateField();
    }

    // Method to evaluate the minefield
    public void evaluateField() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (!minefield[i][j].getStatus().equals("mine")) {
                    minefield[i][j].setStatus("0");
                } else {
                    for (int x = i - 1; x <= i + 1; x++) {
                        for (int y = j - 1; y <= j + 1; y++) {
                            if (x >= 0 && x < rows && y >= 0 && y < columns && !minefield[x][y].getStatus().equals("mine")) {
                                int adjacentMines = Integer.parseInt(minefield[x][y].getStatus());
                                minefield[x][y].setStatus(String.valueOf(adjacentMines + 1));
                            }
                        }
                    }
                }
            }
        }
    }

    // Method to create mines in the minefield
    public void createMines(int x, int y, int mines) {
        Random rand = new Random();
        int count = 0;

        while (count < mines) {
            int randX = rand.nextInt(rows);
            int randY = rand.nextInt(columns);

            if (randX != x && randY != y && !minefield[randX][randY].getStatus().equals("mine")) {
                minefield[randX][randY].setStatus("mine");
                count++;
            }
        }
    }

    // Method to guess a cell
    public boolean guess(int x, int y, boolean flag) {
        if (x >= 0 && x < rows && y >= 0 && y < columns) {
            Cell cell = minefield[x][y];

            if (flag) {
                cell.setStatus("flag");
            } else {
                if (cell.getStatus().equals("mine")) {
                    // Game over if a mine is revealed
                    return true;
                } else if (cell.getStatus().equals("0")) {
                    // Reveal adjacent cells with no adjacent mines
                    revealZeroes(x, y);
                }

                cell.setRevealed(true);
            }
        }

        return false;
    }

    // Method to check if the game is over
    public boolean gameOver() {
        boolean mineRevealed = false;
        boolean allNonMineRevealed = true;
        boolean lastCellRevealed = true;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                Cell cell = minefield[i][j];

                if (cell.getStatus().equals("mine") && cell.getRevealed()) {
                    // Game over if a mine is revealed
                    mineRevealed = true;
                    break;
                }

                if (!cell.getStatus().equals("mine") && !cell.getRevealed()) {
                    // Game not over if a non-mine cell is not revealed
                    allNonMineRevealed = false;
                }

                if (cell.getStatus().equals("mine") && !cell.getRevealed()) {
                    // Game not over if the last cell is not revealed
                    lastCellRevealed = false;
                }
            }

            if (mineRevealed) {
                break;
            }
        }

        return mineRevealed || allNonMineRevealed || lastCellRevealed;
    }

    // Method to reveal adjacent cells with no adjacent mines
    public void revealZeroes(int x, int y) {
        StackGen<Cell> stack = new Stack1Gen<>();
        stack.push(minefield[x][y]);

        while (!stack.isEmpty()) {
            Cell cell = stack.pop();
            int cellX = x;
            int cellY = y;

            // Check the surrounding cells
            for (int i = cellX - 1; i <= cellX + 1; i++) {
                for (int j = cellY - 1; j <= cellY + 1; j++) {
                    if (i >= 0 && i < rows && j >= 0 && j < columns) {
                        Cell surroundingCell = minefield[i][j];

                        if (surroundingCell.getStatus().equals("0") && !surroundingCell.getRevealed()) {
                            stack.push(surroundingCell);
                            surroundingCell.setRevealed(true);
                        }
                    }
                }
            }
        }
    }

    // Method to reveal the starting area
    public void revealStartingArea(int x, int y) {
        QGen<Cell> queue = new Q1Gen<>();
        queue.add(minefield[x][y]);

        while (queue.length() > 0) {
            Cell cell = queue.remove();
            int cellX = x;
            int cellY = y;

            // Check the surrounding cells
            for (int i = cellX - 1; i <= cellX + 1; i++) {
                for (int j = cellY - 1; j <= cellY + 1; j++) {
                    if (i >= 0 && i < rows && j >= 0 && j < columns) {
                        Cell surroundingCell = minefield[i][j];

                        if (!surroundingCell.getRevealed() && !surroundingCell.getStatus().equals("mine")) {
                            queue.add(surroundingCell);
                            surroundingCell.setRevealed(true);
                        }
                    }
                }
            }
        }
    }

    // Method to print the minefield for debugging purposes
    public void debug() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                Cell cell = minefield[i][j];

                if (cell.getStatus().equals("mine")) {
                    System.out.print(ANSI_RED + cell.getStatus() + ANSI_RESTART + " ");
                } else {
                    System.out.print(ANSI_CYAN + cell.getStatus() + ANSI_RESTART + " ");
                }
            }

            System.out.println();
        }
    }

    // Method to convert the minefield to a string representation
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(ANSI_PURPLE).append("  ");
        for (int j = 0; j < columns; j++) {
            sb.append(j).append(" ");
        }
        sb.append("\n");

        for (int i = 0; i < rows; i++) {
            sb.append(ANSI_PURPLE).append(i).append(" ");

            for (int j = 0; j < columns; j++) {
                Cell cell = minefield[i][j];

                if (cell.getRevealed()) {
                    String status = cell.getStatus();

                    switch (status) {
                        case "M":
                            sb.append(ANSI_RED_BRIGHT).append(status).append(" ");
                            break;
                        case "0":
                            sb.append(ANSI_YELLOW).append(status).append(" ");
                            break;
                        case "1":
                            sb.append(ANSI_BLUE_BRIGHT).append(status).append(" ");
                            break;
                        case "2":
                            sb.append(ANSI_GREEN).append(status).append(" ");
                            break;
                        case "3":
                            sb.append(ANSI_RED).append(status).append(" ");
                            break;
                        default:
                            sb.append(ANSI_GREY_BACKGROUND).append(status).append(" ");
                            break;
                    }
                } else {
                    sb.append(ANSI_GREY_BACKGROUND).append("- ");
                }
            }

            sb.append(ANSI_RESTART).append("\n");
        }

        return sb.toString();
    }

    // Method to check if all non-mine cells are revealed
    public boolean allNonMineRevealed() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                Cell cell = minefield[i][j];

                if (cell.getStatus().equals("mine") && !cell.getRevealed()) {
                    return false;
                }
            }
        }

        return true;
    }
}
