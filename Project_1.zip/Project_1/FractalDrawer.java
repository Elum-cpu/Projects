import java.awt.Color;
import java.util.Scanner;
import java.util.Random;

public class FractalDrawer {

    //Initial variable tracker of the total area size of the fractal.
    public static double totalArea = 0;

    //Rand is a random object used to call a random integer.
    Random rand = new Random();

    //Random method to grab random rgb integers to create a random color to set each shape in the fractal using the rand object.
    private Color getRandomColor() {
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        return new Color(r, g, b);
    }

    //Sets the size of the canvas and calls each draw fractal method and gives the parameters of the fractal
    //depending on the string type inputted by the user using switch cases and returns the total area of the fractal.
    public double drawFractal(String type) {
        Canvas can = new Canvas(800,800);
        switch (type) {
            case "triangle":
                drawTriangleFractal(600, 600, 0, 0, getRandomColor(), can, 10);
                break;
            case "rectangle":
                drawRectangleFractal(400, 400, 0, 0, getRandomColor(), can, 10);
                break;
            case "circle":
                drawCircleFractal(150, 50, 100, getRandomColor(), can, 10);
                break;
            default:
                System.out.println("Invalid Shape");
        }
        return totalArea;
    }

    //Draws a triangle fractal using recursive by setting each variable to a new size and position each time it goes through
    //and tracks the area of each shape made and add it to totalArea variable.
    public void drawTriangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level) {
        double newWidth = width / 2;
        double newHeight = height / 2;
        double newX = x + (newWidth / 2);
        double newY = y + (newHeight / 2);
        Triangle tri = new Triangle(newX, newY, newWidth, newHeight);
        tri.setColor(getRandomColor());
        if (level == 0) {
            can.drawShape(tri);
            totalArea += tri.calculateArea();
        }
        else {
            can.drawShape(tri);
            totalArea += tri.calculateArea();
            drawTriangleFractal(width, height, x, y, getRandomColor(), can, level - 1);
            drawTriangleFractal(newWidth, newHeight, newX, y, getRandomColor(), can, level - 1);
            drawTriangleFractal(newWidth, newHeight, x, newY, getRandomColor(), can, level - 1);
            drawTriangleFractal(newWidth, newHeight, newX, newY, getRandomColor(), can, level - 1);
        }
    }

    //Draws a circle fractal using recursive by setting each variable to a new size and position each time it goes through
    //and tracks the area of each shape made and add it to totalArea variable.
    public void drawCircleFractal(double radius, double x, double y, Color c, Canvas can, int level) {
        double newRadius = radius / 2;
        double newX = x + (newRadius / 2);
        double newY = y + (newRadius / 2);
        Circle circ = new Circle(newX, newY, newRadius);
        circ.setColor(c);
        if (level == 0) {
            can.drawShape(circ);
            totalArea += circ.calculateArea();
        }
        else {
            can.drawShape(circ);
            totalArea += circ.calculateArea();
            drawCircleFractal(newRadius, x, y, getRandomColor(), can, level - 1);
            drawCircleFractal(newRadius, newX, y, getRandomColor(), can, level - 1);
            drawCircleFractal(newRadius, x, newY, getRandomColor(), can, level - 1);
            drawCircleFractal(newRadius, newX, newY, getRandomColor(), can, level - 1);
        }
    }

    //Draws a rectangle fractal using recursive by setting each variable to a new size and position each time it goes through
    //and tracks the area of each shape made and add it to totalArea variable.
    public void drawRectangleFractal(double width, double height, double x, double y, Color c, Canvas can, int level) {
        double newWidth = width / 2;
        double newHeight = height / 2;
        double newX = x + newWidth / 2;
        double newY = y + newHeight / 2;
        Rectangle rect = new Rectangle(newX, newY, newWidth, newHeight);
        rect.setColor(c);
        if (level == 0) {
            can.drawShape(rect);
            totalArea += rect.calculateArea();
        }
        else {
            can.drawShape(rect);
            totalArea += rect.calculateArea();
            drawRectangleFractal(newWidth, newHeight, x, y, getRandomColor(), can, level - 1);
            drawRectangleFractal(newWidth, newHeight, x, newY, getRandomColor(), can, level - 1);
            drawRectangleFractal(newWidth, newHeight, newX, y, getRandomColor(), can, level - 1);
            drawRectangleFractal(newWidth, newHeight, newX, newY, getRandomColor(), can, level - 1);
        }
    }

    //Main function that creates a fractal object and takes in the users input and runs each case through the drawFractal
    //method to determine what fractal to draw and return the total area of the fractal.
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        FractalDrawer fractal = new FractalDrawer();
        System.out.println("Enter the shape type: ");
        String shape = myScanner.nextLine();
        switch (shape) {
            case "triangle" -> fractal.drawFractal("triangle");
            case "rectangle" -> fractal.drawFractal("rectangle");
            case "circle" -> fractal.drawFractal("circle");
        }
        double area = totalArea;
        System.out.println("Area: " + area);
    }
}

