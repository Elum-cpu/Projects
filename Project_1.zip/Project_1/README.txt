Elum Nyabando
x500: nyaba009
Chris Dovolis
CSCI 1933
29 September 2023

Project 1: Fractal Drawer

To run the file just make sure to unzip it and navigate to the correct folder when trying to run the 
code. An issue I ran into with my code is that the area wasn’t being returned after completing the fractal but it did end up returning the area when an invalid shape was passed through. As well as when I was typing my if  else statements for the shape and type in my drawFractal and main methods  it would tell me to use the switch case operators instead.

* Idea1: I used this source to figure out how to implement a random function to generate random colors for each of the shapes in the fractal. https://stackoverflow.com/questions/4246351/creating-random-colour-in-java


“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

* Elum Nyabando