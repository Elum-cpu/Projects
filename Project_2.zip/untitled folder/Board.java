public class Board {

    // Instance variables
    public Board[][] board;

    public Board() {
        this.board = new Board[8][8];
    }


    // Accessor Methods
    public Piece getPiece( int row, int col) {
        return board[row][col];
    }

    public void setPiece(int row, int col, Piece piece) {
        piece.setPosition(row, col);
    }

    // Game functionality methods

    public boolean movePiece(int startRow, int startCol, int endRow, int endCol) {
        // Get the piece at the starting position
        Piece piece = board[startRow][startCol];
        // Verify if the source and destination positions are valid
        if (!verifySourceAndDestination(startRow, startCol, endRow, endCol, piece.getIsBlack())) {
            return false;
        }

        // Check if the move is legal for the piece
        if (!piece.isMoveLegal(this, endRow, endCol)) {
            return false;
        }

        // Set the piece at the ending position
        setPiece(endRow, endCol, piece);

        // Clear the starting position
        board[startRow][startCol] = null;

        return true;
    }

    public boolean isGameOver() {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Board piece = board[row][col];
                if (piece instanceof King) {
                    return false;
                }
            }
        }

        return true;
    }

    // Constructs a String that represents the Board object's 2D array.
    // Returns the fully constructed String.
    public String toString() {
        StringBuilder out = new StringBuilder();
        out.append(" ");
        for(int i = 0; i < 8; i++){
            out.append(" ");
            out.append(i);
        }
        out.append('\n');
        for(int i = 0; i < board.length; i++) {
            out.append(i);
            out.append("|");
            for(int j = 0; j < board[0].length; j++) {
                out.append(board[i][j] == null ? "\u2001|" : board[i][j] + "|");
            }
            out.append("\n");
        }
        return out.toString();
    }

    // Sets every cell of the array to null. For debugging and grading purposes.
    public void clear() {
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                board[row][col] = null;
            }
        }
    }

    // Movement helper functions

    public boolean verifySourceAndDestination(int startRow, int startCol, int endRow, int endCol, boolean isBlack) {

        // Check if 'start' and 'end' fall within the array's bounds
        if (startRow < 0 || startRow >= board.length || startCol < 0 || startCol >= board[0].length ||
            endRow < 0 || endRow >= board.length || endCol < 0 || endCol >= board[0].length) {
            return false;
        }
        
        // Check if 'start' contains a Piece object
        if (board[startRow][startCol] == null) {
            return false;
        }
        
        // Check if player's color and color of 'start' Piece match
        if (board[startRow][startCol].getIsBlack() != isBlack) {
            return false;
        }
        
        // Check if 'end' contains either no Piece or a Piece of the opposite color
        if (board[endRow][endCol] != null && board[endRow][endCol].getIsBlack() == isBlack) {
            return false;
        }
        
        return true;
    }

    public boolean verifyAdjacent(int startRow, int startCol, int endRow, int endCol) {
        int rowDiff = Math.abs(startRow - endRow);
        int colDiff = Math.abs(startCol - endCol);
    
        return rowDiff == 1 && colDiff == 1;
    }

    public boolean verifyHorizontal(int startRow, int startCol, int endRow, int endCol) {
        // Check if the entire move takes place on one row
        if (startRow != endRow) {
            return false;
        }
        
        // Check if all spaces directly between 'start' and 'end' are empty
        int minCol = Math.min(startCol, endCol);
        int maxCol = Math.max(startCol, endCol);
        
        for (int col = minCol + 1; col < maxCol; col++) {
            if (board[startRow][col] != null) {
                return false;
            }
        }
        
        return true;
    }

    public boolean verifyVertical(int startRow, int startCol, int endRow, int endCol) {
        // Check if the entire move takes place on one column
        if (startCol != endCol) {
            return false;
        }

        // Check if all spaces directly between 'start' and 'end' are empty
        int minRow = Math.min(startRow, endRow);
        int maxRow = Math.max(startRow, endRow);

        for (int row = minRow + 1; row < maxRow; row++) {
            if (board[row][startCol] != null) {
                return false;
            }
        }

        return true;
    }

    public boolean verifyDiagonal(int startRow, int startCol, int endRow, int endCol) {
        // Check if the path from 'start' to 'end' is diagonal
        int rowDiff = Math.abs(startRow - endRow);
        int colDiff = Math.abs(startCol - endCol);
        
        if (rowDiff != colDiff) {
            return false;
        }
        
        // Check if all spaces directly between 'start' and 'end' are empty
        int minRow = Math.min(startRow, endRow);
        int maxRow = Math.max(startRow, endRow);
        int minCol = Math.min(startCol, endCol);
        int maxCol = Math.max(startCol, endCol);
        
        int row = minRow + 1;
        int col = minCol + 1;
        
        while (row < maxRow && col < maxCol) {
            if (board[row][col] != null) {
                return false;
            }
            
            row++;
            col++;
        }
        
        return true;
    }
}
