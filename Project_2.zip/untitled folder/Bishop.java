public class Bishop {
    // Instance variables
    private int row;
    private int col;
    private boolean isBlack;

    /**
     * Constructor.
     * @param row       The current row of the rook.
     * @param col       The current column of the rook.
     * @param isBlack   The color of the rook.
     */
    public Bishop(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    /**
     * Checks if a move to a destination square is legal for a knight.
     * @param board     The game board.
     * @param endRow    The row of the destination square.
     * @param endCol    The column of the destination square.
     * @return True if the move to the destination square is legal for a knight, false otherwise.
     */
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        // Check if the move is diagonal
        int rowDiff = Math.abs(endRow - this.row);
        int colDiff = Math.abs(endCol - this.col);
        
        if (rowDiff != colDiff) {
            return false;
        }
        
        // Check if there are any pieces in the path from start to end
        int rowDirection = (endRow > this.row) ? 1 : -1;
        int colDirection = (endCol > this.col) ? 1 : -1;
        
        int currentRow = this.row + rowDirection;
        int currentCol = this.col + colDirection;
        
        while (currentRow != endRow && currentCol != endCol) {
            if (board.getPiece(currentRow, currentCol) != null) {
                return false;
            }
            
            currentRow += rowDirection;
            currentCol += colDirection;
        }
        
        // Check if the destination square is empty or contains an opponent's piece
        if (!board.verifySourceAndDestination(row, col, endRow, endCol, isBlack)) {
            return false;
        }
        
        return false;
    }

}
