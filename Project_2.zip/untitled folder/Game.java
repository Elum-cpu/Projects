import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        // Instantiate the Board object
        Board board = new Board();

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Print the initial board state
        printBoard(board);

        // Start the game loop
        while (!GameOver(board)) {
            // Prompt the user for input
            System.out.print("Enter starting row: ");
            int startRow = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter starting column: ");
            int startCol = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter ending row: ");
            int endRow = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter ending column: ");
            int endCol = Integer.parseInt(scanner.nextLine());
            board.movePiece(startRow, startCol, endRow, endCol);
            printBoard(board);
        }
        // Game over
        System.out.println("Game over!");
    }

    private static void printBoard(Board board) {
            System.out.println(board.toString());
    }


    private static boolean GameOver(Board board) {
        if (board.isGameOver()) {
            System.out.println("Game over!");
        }
        return false;
    }
}
