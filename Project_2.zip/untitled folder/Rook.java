public class Rook {
    // Instance variables
    private int row;
    private int col;
    private boolean isBlack;

    /**
     * Constructor.
     * @param row       The current row of the rook.
     * @param col       The current column of the rook.
     * @param isBlack   The color of the rook.
     */
    public Rook(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }

    /**
     * Checks if a move to a destination square is legal for a rook.
     * @param board     The game board.
     * @param endRow    The row of the destination square.
     * @param endCol    The column of the destination square.
     * @return True if the move to the destination square is legal, false otherwise.
     */
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        if (board.verifyHorizontal(this.row, this.col, endRow, endCol) ||
            board.verifyVertical(this.row, this.col, endRow, endCol)) {
            // Case 1: Moving vertically or horizontally.
            // Determine if the path is clear and the destination square is empty or contains a piece of the opposite color.
            if (board.getPiece(endRow, endCol) == null ||
                board.getPiece(endRow, endCol).getIsBlack() != this.isBlack) {
                // The destination square is empty or contains a piece of the opposite color.
                if (board.verifyHorizontal(this.row, this.col, endRow, endCol)) {
                    // Check if all spaces directly between the current position and the destination square are empty.
                    int minCol = Math.min(this.col, endCol);
                    int maxCol = Math.max(this.col, endCol);

                    for (int col = minCol + 1; col < maxCol; col++) {
                        if (board.getPiece(this.row, col) != null) {
                            return false;
                        }
                    }
                } else {
                    // Check if all spaces directly between the current position and the destination square are empty.
                    int minRow = Math.min(this.row, endRow);
                    int maxRow = Math.max(this.row, endRow);

                    for (int row = minRow + 1; row < maxRow; row++) {
                        if (board.getPiece(row, this.col) != null) {
                            return false;
                        }
                    }
                }

                return true;
            }
        }

        return false;
    }
}
