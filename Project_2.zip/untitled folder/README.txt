Elum Nyabando x500: nyaba009

I wrote the majority of the code on Visual Studio Code and switched to IntelliJ to run the tests and finish the code.
It can be ran however the users prefers.

“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

-Elum Nyabando